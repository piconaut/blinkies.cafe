﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “transbro”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/2151214

*NOTE: “Offical Emotes.” was originally cloned (copied) from the
FontStruction “Emotes!” (https://fontstruct.com/fontstructions/show/2151209)
by “piconaut”, which is licensed under a Creative Commons Attribution Share
Alike license (http://creativecommons.org/licenses/by-sa/3.0/).
“Emotes!” was in turn cloned (copied) from the FontStruction “Emotes!”
(https://fontstruct.com/fontstructions/show/2151195) by “transbro”, which is
licensed under a Creative Commons Attribution Share Alike license
(http://creativecommons.org/licenses/by-sa/3.0/).
“Emotes!” was in turn cloned (copied) from the FontStruction “test monaco
emotes” (https://fontstruct.com/fontstructions/show/2151174) by
“piconaut”, which is licensed under a Creative Commons Attribution Share
Alike license (http://creativecommons.org/licenses/by-sa/3.0/).
“test monaco emotes” was in turn cloned (copied) from the FontStruction
“emotes” (https://fontstruct.com/fontstructions/show/2151036) by
“transbro”, which is licensed under a Creative Commons Attribution Share
Alike license (http://creativecommons.org/licenses/by-sa/3.0/).
“emotes” was in turn cloned (copied) from the FontStruction “Monaco”
(https://fontstruct.com/fontstructions/show/753435) by Jamie Place, which is
licensed under a Creative Commons Attribution Share Alike license
(http://creativecommons.org/licenses/by-sa/3.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2022 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
